from distutils.core import setup

setup(
    name='test',
    version='1.0',
    py_modules=['test'],
)
